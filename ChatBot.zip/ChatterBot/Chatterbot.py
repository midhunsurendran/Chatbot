from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
import os

bot=ChatBot('Bot')
bot.set_trainer(ListTrainer)

for files in os.listdir('C:/Users/Mike Sierra/Desktop\ChatterBot/chatterbot-corpus-master\chatterbot_corpus\data\english/'):
	data=open('C:/Users/Mike Sierra/Desktop\ChatterBot/chatterbot-corpus-master\chatterbot_corpus\data\english/'+ files, 'r').readlines()
	bot.train(data)

while True:
	message= input('You: ')
	if message.strip()!='bye':
		replay=bot.get_response(message)
		print('ChatBot: ',replay)
	if message.strip()=='bye':
		print('ChatBot: Bye See you Again')
		break